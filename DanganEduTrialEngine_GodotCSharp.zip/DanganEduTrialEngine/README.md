# DanganEdu Trial Engine

A modular Godot 4 C# starter project for a **high-fidelity educational trial engine** inspired by class-trial mechanics:

- 2D Visual Novel phase
- Nonstop Debate contradiction phase
- 3D Logic Dive equation-path runner
- Global countdown timer
- Focus gauge for slow-motion debate reading
- Rewind stack for 3D physics snapshots
- Local PNG/WAV asset loading through manifests

This package intentionally includes **no copyrighted Danganronpa sprites, sounds, music, logos, or ripped assets**. Add your own legal placeholder/original assets under `res://assets_local/` or point the loader at an external directory.

## Engine target

- Godot 4.x
- C# / .NET
- 2D + 3D hybrid scene architecture

## Main idea

The project is split into clean systems:

```txt
Core           -> phase changes, timer, focus, scene transitions
Assets         -> manifest loading, PNG/WAV cache, audio playback
Debate         -> weak points, truth bullets, moving text, contradiction resolution
LogicDive      -> 3D runner, branch gates, equation problems, rewind buffer
VN             -> dialogue sequencing and character sprites
UI             -> timer/focus HUD and fade overlay
Utils          -> JSON loading, node guard helpers, math text formatting
Data           -> editable trial scripts and problem files
Scripts        -> Python helper tools
```

## Quick start

1. Open this folder in Godot 4 with .NET support.
2. Let Godot generate/import C# metadata.
3. Open `scenes/Main.tscn`.
4. Run the project.
5. Put legal `.png` and `.wav` assets in `assets_local/` or edit the JSON manifests in `data/`.

## Input map

The project includes the expected input action names in `project.godot`:

```txt
fire_truth      -> left mouse / enter
fire_silencer   -> right mouse
focus           -> shift
lane_left       -> A / left arrow
lane_right      -> D / right arrow
rewind          -> R
advance_dialog  -> space / enter
```

## Data files

- `data/characters.json`
- `data/audio_manifest.json`
- `data/debate_math_trial_001.json`
- `data/logic_dive_problems_001.json`
- `data/game_config.json`

The whole point is to build trials by editing data, not by hardcoding everything like a raccoon with Visual Studio access.
